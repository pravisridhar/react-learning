import { createStyles, Grid, makeStyles, Paper, TextField, Theme, Typography } from '@material-ui/core'
import { useFormik } from 'formik';
import React, { ReactElement, ReactNode } from 'react'
import PageHeader from '../../components/PageHeader';
import { useProduct } from '../../config/AppContext';
import { validationSchema } from '../data/ProductModel';
import UpdateIcon from "@material-ui/icons/Update";
import CustomButton from "../../controls/CustomButton";
import { Link, useHistory } from 'react-router-dom';
import { ProductLocalDataSource } from '../data/ProductLocalDataSource';
import { ProductService } from '../data/ProductService';
import { useDispatch, useSelector } from 'react-redux';
import { productEditActionCreator } from '../../config/ReactReduxStore';

interface Props {
    children: ReactNode,
    [others: string]: any
}
const useStyles = makeStyles((theme: Theme) => createStyles({
    root: {
        "& .MuiFormControl-root": {
            width: '80%',
            margin: theme.spacing(1)
        },
        "& > * + *": {
            width: '80%',
            margin: theme.spacing(1)
        }
    },
    pageContent: {
        padding: theme.spacing(3),
        margin: theme.spacing(5)
    }

}))

function ProductUpdate(props: Props): ReactElement {
    
    const classes = useStyles();
    //const {state, dispatch} = useProduct();
    const dispatch = useDispatch();
    const state = useSelector((state: any) => state.products)
    const history = useHistory();

    const formik = useFormik({
        initialValues: state.selectedProduct,
        validationSchema: validationSchema,
        onSubmit: (values) => {
            //alert('validated');
            //ProductLocalDataSource.update(values);
            let service = new ProductService();
            service.updateProduct(values);
            //dispatch({type:"UpdateProduct", payload:{selectedProduct: values}});
            dispatch(productEditActionCreator({
                selectedProduct: values,
                selectedId: values.productId
            }));
            history.push("/products");
        }
    })
    return (
        <>
            <PageHeader
                pageTitle="Update Products" pageSubTitle="update the product details here."
                displayIcon={<UpdateIcon fontSize="small" />} />
            <Paper className={classes.pageContent}>
                <form className={classes.root} autoComplete="off" onSubmit={formik.handleSubmit} >
                    <TextField
                        fullWidth
                        id="productName"
                        name="productName"
                        label="Product Name"
                        variant="outlined"
                        value={formik.values.productName}
                        onChange={formik.handleChange}
                        error={formik.touched.productName && Boolean(formik.errors.productName)}
                        helperText={formik.touched.productName && formik.errors.productName}
                    />
                    <TextField
                        fullWidth
                        id="unitPrice"
                        name="unitPrice"
                        label="Unit Price"
                        variant="outlined"
                        value={formik.values.unitPrice}
                        onChange={formik.handleChange}
                        error={formik.touched.unitPrice && Boolean(formik.errors.unitPrice)}
                        helperText={formik.touched.unitPrice && formik.errors.unitPrice}
                    />
                    <TextField
                        fullWidth
                        id="unitsInStock"
                        name="unitsInStock"
                        label="stock Level"
                        variant="outlined"
                        value={formik.values.unitsInStock}
                        onChange={formik.handleChange}
                        error={formik.touched.unitsInStock && Boolean(formik.errors.unitsInStock)}
                        helperText={formik.touched.unitsInStock && formik.errors.unitsInStock}
                    />
                    <Grid container>
                        <Grid item>
                            <CustomButton text="Submit" type="submit" name="submit" color="secondary" size="large" />
                        </Grid>
                        <Grid item>
                            <Link to="/products">
                                <CustomButton text="Discard" type="button" name="btn2" color="default" />
                            </Link>
                        </Grid>
                    </Grid>
                </form>
            </Paper>
        </>
    )
}

export default ProductUpdate
