//Folder: Products 
//  Sub Folder: basic
//      Sub Folder: data 
//          File: ProductModel.ts
import * as yup from "yup";

export class ProductModel {
    constructor(
        public productId: number,
        public productName: string,
        public unitPrice: number,
        public unitsInStock: number,
    ) {

    }
}

export const validationSchema = yup.object({
    productName: yup.string()
        .label("Product Name")
        .min(3, 'Product name should be at least 3 chars')
        .max(50, 'product name can be a max of 50 chars')
        .required('Product Name is required.'),
    unitPrice: yup.number()
        .label('Unit Price')
        .min(0, 'Unit price cannot be less than 0')
        .max(1000, 'Unit price cannot be greater than 1000.')
        .required('Unit price is required.'),
    unitsInStock: yup.number()
        .label('Stock Level')
        .min(0, 'Stock level cannot be less than 0')
        .max(1000, 'Stock Level cannot be greater than 1000.')
        .required('Stock Level is required.')
});
