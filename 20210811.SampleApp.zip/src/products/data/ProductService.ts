import {ProductModel} from "./ProductModel"
import axios, {AxiosRequestConfig} from "axios";
import { Block } from "@material-ui/icons";

const ProductUrl:string = "http://localhost:5001/products"; 

export class ProductService {
    
    async fetchAllProducts() : Promise<ProductModel[]> { 
        let config:AxiosRequestConfig = { 
            url: ProductUrl, 
            timeout: 10000,
            timeoutErrorMessage:'Could not connect.'
        } 
        let response = await axios.get<ProductModel[]>(ProductUrl, config);
        let data = response.data; 
        return data; 
    }

    fetchProductDetails() { 
        return axios.get<ProductModel>(ProductUrl);
    } 
    async createProduct(item: ProductModel) : Promise<void> { 
        let requestConfig:AxiosRequestConfig ={ 
            url:ProductUrl,
            method: 'POST', 
            data: JSON.stringify(item), 
            headers: {
                'Content-Type' : 'application/json'
            }
        };
        await axios( requestConfig );
        return;
    } 
    async updateProduct(item: ProductModel) : Promise<void> { 
        let requestConfig:AxiosRequestConfig ={ 
            url:`${ProductUrl}/${item.productId}`,  //http://localhost:5001/products/78 
            method: 'PUT', 
            data: JSON.stringify(item), 
            headers: {
                'Content-Type' : 'application/json'
            }
        };
        await axios( requestConfig );
        return;
    } 
}


