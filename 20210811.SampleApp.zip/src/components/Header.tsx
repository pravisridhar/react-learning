import { AppBar, Badge, createStyles, Grid, IconButton, makeStyles, Theme, Toolbar, Typography } from '@material-ui/core'
import React, { ReactElement } from 'react'
import NotificationsNoneIcon from "@material-ui/icons/NotificationsNone";
import PowerSettingsNewIcon from "@material-ui/icons/PowerSettingsNew";
import "../index.css";
import MenuIcon from "@material-ui/icons/Menu"
import { useSelector } from 'react-redux';

const useStyles = makeStyles((theme: Theme) => createStyles({
    root: {
        backgroundColor: "#fff",
        display: "flex"
    },
    menuButton: {
        marginRight: theme.spacing(2),
        //   [theme.breakpoints.up('sm')]: {
        //     display: 'none',
        //   },
    }

}));

interface Props {
    open: boolean,
    setOpen(value: boolean): any,
    handleToggle(): void
}

function Header({ open, setOpen, handleToggle }: Props): ReactElement {
    //use the useStyles hook 
    const classes = useStyles();

    const tracker = useSelector((state:any) => state.tracker)

    return (
        <AppBar position="fixed" className={classes.root} >
            <Toolbar>
                <Grid container alignItems="center">
                    <Grid item> {/* md={8} lg={12} sm={6} */}
                        <IconButton
                            color="inherit"
                            aria-label="open drawer"
                            edge="start"
                            onClick={handleToggle}
                            className={classes.menuButton}
                        >
                            <MenuIcon />
                        </IconButton>
                    </Grid>
                    <Grid item>
                        <Typography variant="h4" component="span" color="primary">
                            Northwind Traders
                        </Typography>
                    </Grid>
                    <Grid item lg md sm xs></Grid>
                    <Grid item>
                        <IconButton>
                            <Badge badgeContent={tracker} color="primary">
                                <NotificationsNoneIcon />
                            </Badge>
                        </IconButton>
                        <IconButton color="secondary" 
                        onClick={(e)=>{
                            localStorage.removeItem("auth"); 
                            window.location.href="/home"
                        }}>
                            <PowerSettingsNewIcon />
                        </IconButton>

                    </Grid>
                </Grid>

            </Toolbar>
        </AppBar>
    )
}

export default Header
