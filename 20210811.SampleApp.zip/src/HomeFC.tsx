import { Typography } from '@material-ui/core';
import { ErrorMessage, Field, Form, Formik, useFormik } from 'formik';
import React, { ReactElement } from 'react'
import { useState } from 'react'
import CustomButton from './controls/CustomButton';
import * as yup from "yup";

interface IHomeFCProps {
    title?: string
}

const UserSchema = yup.object({
    userName: yup.string()
            .min(3, 'Username should be atleast 3 chars.')
            .max(20, 'username should not be more than 20 chars.')
            .required('Username is required'), 
    address: yup.string()
            .required('Address is required.'),
    userType:yup.string().oneOf(['Admin', 'User'], 'select a valid user type')
            .required('user type is required.')
});

function HomeFC(props: IHomeFCProps): ReactElement {

    //Hooks - available in Functional Components 
    const [counter, setCounter] = useState(0);
    const [user, setUser] = useState({ userName: 'MyName', address: 'ss' });

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        setCounter(counter + 1);
    }
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        let target = e.target;
        setUser({ ...user, [target.name]: target.value });
        console.log(user);
    }
    const onSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        //if (user.userName.length < 5)

    }
    const validate=(values:{userName:string, address:string}) =>{
        const errors:{userName:string, address:string}={userName:'', address:''};
        if(!values.userName)
            errors.userName = "Username is required."; 
        else if(values.userName.length<4)
        errors.userName="Length should be at least 4."; 
        return errors;
    }
    const formik = useFormik({
        initialValues: {
            userName: 'Name', address: "address", userType:''
        },
        //validate,
        validationSchema:UserSchema,
        onSubmit: (values, {setSubmitting}) => {
            setSubmitting(false);
            alert(JSON.stringify(values, null, 2));
        }
    })
    return (
        <div style={{ textAlign: 'center', marginTop: '50px', marginLeft: '50px' }}>
            <Typography variant="subtitle1">{props.title}</Typography>
            <p>
                counter is <span>{counter}</span>
                <CustomButton onClick={handleClick} text="Update Me" name="t1" />
            </p>
            <form onSubmit={onSubmit}>
                Enter Name:
                <input type="text"
                    name="userName"
                    id="userName"
                    value={user.userName}
                    onChange={handleChange} />
                <br />
                Enter Address:
                <input type="text"
                    name="address"
                    id="address"
                    value={user.address}
                    onChange={handleChange} />
            </form>

            <hr />
            <Formik 
                 
                 initialValues= {{
                    userName: 'Name', address: "address", userType:''
                 }} 
                //validate,
                validationSchema={UserSchema} 
                onSubmit= {(values, {setSubmitting}) => {
                    setSubmitting(false);
                    alert(JSON.stringify(values, null, 2));
                }}>
               
            <Form>

            { (!formik.isValid) ? ( 
                    (<div>
                        {formik.errors.address}
                        {formik.errors.userName}
                        {formik.errors.userType}
                        </div>)
                ) : (<div></div>)
                }
                <label htmlFor="userName">User Name: </label>
                <input type="text" id="userName" name="userName"
                onChange={formik.handleChange}
                value={formik.values.userName}/>
                {formik.touched.userName && formik.errors.userName ? 
                    <div>{formik.errors.userName}</div>
                    : null}
                <label htmlFor="userName">Address: </label>
                <input type="text" id="address" name="address"
                onChange={(e)=> { handleChange(e); formik.handleChange(e);}}
                value={formik.values.address}/>
                 {formik.touched.address && formik.errors.address ? 
                    <div>{formik.errors.address}</div>
                    : null}
                    <br/>
                    <label htmlFor="usertype">User Type: </label>
                <Field as="select" name="userType">
                    <option value="">--Select--</option>
                    <option value="Admin">Admin</option>
                    <option value="User">User</option>
                </Field>
                <ErrorMessage name="userType"/>
                <button type="submit" disabled={!formik.isValid || formik.isSubmitting}>Submit</button>
            </Form>
                    </Formik>
        </div>
    )
}

export default HomeFC
