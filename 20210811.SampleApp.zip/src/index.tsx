import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import "react-app-polyfill/ie11";
import {IAppState} from "./config/IAppState";
import { ProductModel } from './products/data/ProductModel';
import { AppContextProvider } from './config/AppContext';
import { Provider } from 'react-redux';
//import { createStore } from 'redux';
import store from "./config/ReactReduxStore";

//const initialState:IAppState=


ReactDOM.render(
  // <React.StrictMode>
  // <AppContextProvider>
  <Provider store={store}>
    <App />
  </Provider>
  // </AppContextProvider>
  // </React.StrictMode>,
 , document.getElementById('root')
);

// // If you want to start measuring performance in your app, pass a function
// // to log results (for example: reportWebVitals(console.log))
// // or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();

// const initialState = {items:[]} 
// const ADD_ITEM = "ADD_ITEM"; 
// function addItem(data) { 
//   return { type:ADD_ITEM, payload:data}
// }
// function reducer(state, action){
//   state = state || initialState; 
//   switch (action.type){
//     case ADD_ITEM: 
//       state.items.push(action.payload); 
//       return {...state};
//   }
// }
// const store = createStore(reducer); 
// window.store = store; 
// window.addItem = addItem;
