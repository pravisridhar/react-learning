import { connectRouter, routerMiddleware } from "connected-react-router";
import { createBrowserHistory } from "history";
import { applyMiddleware, combineReducers, compose, createStore } from "redux";
import thunk from "redux-thunk";
import {ProductModel} from "../products/data/ProductModel"
import logger from "redux-logger";
import {composeWithDevTools} from "redux-devtools-extension"

//Action Constants 
const CREATE_PRODUCT="CREATE_PRODUCT"; 
const EDIT_PRODUCT="EDIT_PRODUCT"; 
const SELECT_PRODUCT="SELECT_PRODUCT"; 
const SELECT_ALL_PRODUCT="SELECT_ALL_PRODUCT"; 

interface IProductGetAllAction { 
    type: typeof SELECT_ALL_PRODUCT,
    payload: { productList:Array<ProductModel>}
}
interface IProductSelectAction { 
    type: typeof SELECT_PRODUCT,
    payload: { selectedProduct: ProductModel, selectedId:number }
}
interface IProductCreateAction { 
    type: typeof CREATE_PRODUCT,
    payload: { selectedProduct: ProductModel, selectedId:number }
}
interface IProductEditAction { 
    type: typeof EDIT_PRODUCT,
    payload: { selectedProduct: ProductModel, selectedId:number }
}

type ProductActionTypes = IProductSelectAction|IProductGetAllAction|IProductCreateAction|IProductEditAction; 
//Action Creator functions 
export const productGetAllActionCreator = (data: {
    productList:Array<ProductModel>
}): IProductGetAllAction => { 
    return { 
        type:SELECT_ALL_PRODUCT, 
        payload: { 
            productList: data.productList
        }
    }
}
export const productSelectActionCreator = (data: {
    selectedProduct: ProductModel, 
    selectedId:number
}): IProductSelectAction => { 
    return { 
        type:SELECT_PRODUCT, 
        payload: { 
            selectedProduct: data.selectedProduct, 
            selectedId:data.selectedId
        }
    }
}
export const productCreateActionCreator = (data: {
    selectedProduct: ProductModel, 
    selectedId:number
}): IProductCreateAction=> { 
    return { 
        type:CREATE_PRODUCT, 
        payload: { 
            selectedProduct: data.selectedProduct, 
            selectedId:data.selectedId
        }
    }
}
export const productEditActionCreator = (data: {
    selectedProduct: ProductModel, 
    selectedId:number
}): IProductEditAction => { 
    return { 
        type:EDIT_PRODUCT, 
        payload: { 
            selectedProduct: data.selectedProduct, 
            selectedId:data.selectedId
        }
    }
}

//Initial State for products 
const productInitialState ={
    productList: [],
    selectedProduct: new ProductModel(0, ' ', 0, 0), 
    selectedId:0
}

//Define the product reducer 
const productReducer =(
    state = productInitialState, 
    action:ProductActionTypes
) => {
    switch(action.type){
        case SELECT_ALL_PRODUCT: 
            return {...state, productList:action.payload.productList}
        case SELECT_PRODUCT: 
            return {
                ...state, 
                selectedProduct:action.payload.selectedProduct,
                selectedId: action.payload.selectedId
            }
        case CREATE_PRODUCT: 
            return {
                ...state, 
                selectedProduct:action.payload.selectedProduct,
                selectedId: action.payload.selectedId
            }
        case EDIT_PRODUCT: 
            return {
                ...state, 
                selectedProduct:action.payload.selectedProduct,
                selectedId: action.payload.selectedId
            }
        default: 
            return state; 
    }
}
//// Here ends the product vertical 

///Another vertical 
const activityTrackerReducer = ( 
    state:number = 0, 
    action:ProductActionTypes
) => {
    switch(action.type) {
        case SELECT_ALL_PRODUCT: 
        case SELECT_PRODUCT: 
        case CREATE_PRODUCT: 
        case EDIT_PRODUCT: 
            return state + 1; 
        default: 
            return state; 
    }
}

///// end of ativity vertical 



/// Application level code starts from here. 
//Other reducers can be include 
export const history = createBrowserHistory();  //history

const reducers = (history:any) => combineReducers({
    router: connectRouter(history), 
    products: productReducer,
    tracker:activityTrackerReducer
}); 

const middleWares=[
    thunk,
    routerMiddleware(history),
    logger
]; 

const store = createStore(
    reducers(history), 
    composeWithDevTools(applyMiddleware(...middleWares))
)

export default store;





