import React, { useReducer } from "react";
import { ProductModel } from "../products/data/ProductModel";
import { IAppState } from "./IAppState";


interface IProductGetAllAction { 
    type: "AllProducts", 
    payload: { 
        productList: Array<ProductModel>
    }
}
interface IProductSelectAction { 
    type: "ProductDetails", 
    payload: { 
        selectedProduct: ProductModel,
        selectedProductId: number
    }
}
interface IProductCreateAction { 
    type: "CreateProduct", 
    payload: { 
        selectedProduct: ProductModel,
    }
}
interface IProductUpdateAction { 
    type: "UpdateProduct", 
    payload: { 
        selectedProduct: ProductModel
    }
}
const initialAppState:IAppState = {
    appName:"Sample app", 
    isAuthenticate:false, 
    user:{ userName:"", fullName:""},
    products:{
        productList:[], 
        selectedProduct:new ProductModel(0, "", 0, 0),
        selectedProductId:0,
        isLoading:true,
        errors: ""
    }
}

function appReducer<IAppState>(state:any, action:ProductActions) { 
    //Initial state 
    //state should never be undefined. It should always have default values. 
    state = state || initialAppState; 

    switch (action.type){
        case "AllProducts": 
            return { 
                ...state, 
                products: { 
                    ...state.products, 
                    productList:action.payload.productList
                }
            };
        case "ProductDetails": 
            return { 
                ...state, 
                products: { 
                    ...state.products, 
                    selectedProduct:action.payload.selectedProduct,
                    selectedProductId: action.payload.selectedProductId
                }
            };
        case "CreateProduct": 
            return { 
                ...state, 
                products: { 
                    ...state.products, 
                    selectedProduct:action.payload.selectedProduct
                }
            };
        case "UpdateProduct": 
            return { 
                ...state, 
                products: { 
                    ...state.products, 
                    selectedProduct:action.payload.selectedProduct,
                }
            };
        default: 
            return state;
    }
}
type ProductActions = IProductGetAllAction 
                    | IProductSelectAction 
                    | IProductCreateAction 
                    | IProductUpdateAction
type Dispatch = (action: ProductActions) => void; 
//==================================================================== 

export const AppContext = React.createContext<
    {state:IAppState, dispatch:Dispatch} | undefined >(undefined);


export function AppContextProvider({children}: {children:React.ReactNode}){
    const[state, dispatch] = useReducer(appReducer, initialAppState);
    const value = {state, dispatch}; 
    return (
        <AppContext.Provider value={value}>
            {children}
        </AppContext.Provider>
    )
}
//Create a useHook which can be plugged in from functional components 
export function useProduct() { 
    const context = React.useContext(AppContext); 
    if(context === undefined )
        throw new Error ("useProduct hook should be called within an AppContext Provider"); 
    return context;
}
//Component Levvel:   const { state, dispatch} = useProduct(); 

