import React, { Component } from "react";

interface IPageTitleProps { 
    title:string, 
    subtitle?:string, 
    color?:string
  }
  //Props or properties =. immutable data - cannot change
  //const PageTitle = ({title}:{title:string}) =>{
 export const PageTitle = (props:IPageTitleProps) =>{
    //title="New Title";
    return <h2>{props.title}</h2>
  };

 export const PageSubTitle = (props:IPageTitleProps) => 
    <h4 style={{ backgroundColor:props.color,padding:"5px", margin:'2px' }}>{props.subtitle}</h4>


interface IHeaderProps {   // I<Component><Purpose> 
    title?:string,
    subtitle?:string
}
interface IHeaderState { 

}
export class Header1 extends Component<IHeaderProps, IHeaderState> {
    constructor({title="Sample", subtitle="subtitle"}:IHeaderProps){
        super({title:title, subtitle:subtitle});
    }
    render() { 
        return (
            // <div>
            <React.Fragment>
                <PageTitle title={this.props.title || "empty"} />
                <PageSubTitle title="ee" color="deepskyblue" subtitle={this.props.subtitle || "empty"}/>
            </React.Fragment>
            // </>
        );
    }
}

