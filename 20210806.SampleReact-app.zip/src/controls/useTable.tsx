import { createStyles, Theme, makeStyles, Table, TableHead, TableRow, TableCell, TablePagination } from "@material-ui/core";
import React, { ReactNode, useState } from "react";

interface IUseTableInputProps { 
    records: Array<{}>, 
    headerCells: Array<ITableHeaderCell>,
    children? :ReactNode
}
export interface ITableHeaderCell {
    id: keyof any, 
    title?: string, 
    label: string
 }
 interface IUseTableOutputProps { 
     TblContainer : any, 
     TblHeader: any, 
     TblPagination: any
     recordsAfterPagination() : Array<{}>
 }
 const useStyles = makeStyles((theme:Theme)=>createStyles({
    table: { 
        marginTop: theme.spacing(2), 
        "& thead th" : {
            fontWeight:'600',
            color:theme.palette.primary.dark,
            backgroundColor:theme.palette.primary.light
        },
        '& tbody td': {
            fontWeight: '300'
        }, 
        '& tbody tr:hover': { 
            backgroundColor:'#a2a2a2',
            cursor:'pointer'
        }
    }
 }))
 export function useTable({records, headerCells, children}:IUseTableInputProps) : IUseTableOutputProps { 
    const classes = useStyles(); 
    
    const TblContainer = ({children}:any) =>(
        <Table className={classes.table}>
                {children}
        </Table>
    )

    const pages = [3, 6, 9]; //number of items to be displayed on the page 
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(pages[page]);

    const handlePageChange = 
        (event:React.MouseEvent<HTMLButtonElement> | null, newPage:number)=>{
            setPage(newPage);
    }
    const handleRowsPerPageChange = (
        event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => { 
        setRowsPerPage(parseInt(event.target.value, 10)); 
        setPage(0);
    }
    const TblPagination = (props:any) => ( 
        <TablePagination
            component="div"
            page={page}
            rowsPerPageOptions={pages}
            rowsPerPage={rowsPerPage}
            count={props.records.length}
            onPageChange={handlePageChange}
            onRowsPerPageChange={handleRowsPerPageChange}
            />
    );

    const TblHeader = (props: any) => (
        <TableHead>
            <TableRow>
                {
                    props.header.map(
                        (item: any) => (
                            <TableCell key={item.id}>
                                {item.label}
                            </TableCell>
                        )
                    )
                }
            </TableRow>
        </TableHead>
    )
    const recordsAfterPagination = ():Array<{}> => { 
        return  records.slice(page*rowsPerPage, (page+1) * rowsPerPage);
    }
    return { 
        TblContainer, 
        TblHeader,
        TblPagination,
        recordsAfterPagination
    }
 }