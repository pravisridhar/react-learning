import React, { ReactElement } from 'react'
import CustomButton from './CustomButton'

interface Props {
    
}

function LoginComponent({}: Props): ReactElement {
    return (
        <div style={{marginTop:'100px'}}> 
            <CustomButton name="signIn" text="Sign In" size="large" color="primary"
                onClick={(e)=>{
                    localStorage.setItem("auth", "true"); 
                    window.location.href="/home"
                }}/>
                <CustomButton name="cancel" text="Cancel" size="large" color="secondary"
                    />
        </div>
    )
}

export default LoginComponent
