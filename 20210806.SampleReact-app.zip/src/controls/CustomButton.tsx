import { createStyles, makeStyles, Theme, Button } from '@material-ui/core'
import React, { ReactElement } from 'react'

interface ICustomButtonProps {
    name:string, text:string, color?:any, size?:any, variant?:any,
    onClick?(e:React.MouseEvent<HTMLButtonElement>):void,
    [others:string]:any 
}

const useStyles=makeStyles((theme:Theme)=>createStyles({
    root: { 
        margin:theme.spacing(0.5)
    }, 
    label: { 
        textTransform:"none"
    }
}))

function CustomButton(props: ICustomButtonProps): ReactElement {
    const classes=useStyles();
    const {variant, color, size, onClick, text, ...others}=props;
    return (
        <Button variant={variant || "contained"}
                color={color || "primary"}
                size = {size || "large"}
                onClick={onClick}
                {...others}
                classes={{root:classes.root, label:classes.label}}
                >
                    {text}
        </Button>
    )
}

export default CustomButton
