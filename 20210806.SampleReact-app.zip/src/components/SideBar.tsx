import {
    createStyles,
    Divider,
    Drawer,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    makeStyles,
    Theme,
    Typography,
    useTheme
} from '@material-ui/core';

import React, { ReactElement } from 'react'
import HomeWorkIcon from '@material-ui/icons/HomeWork';
import ProductsIcon from "@material-ui/icons/SettingsInputCompositeSharp";
import { useState } from 'react';
import { routes } from "../config/route.config";
import { RouteItem } from "../config/RouteItem";
import { Link } from "react-router-dom";

const drawerWidth = 240;

const useStyles = makeStyles((theme: Theme) => createStyles({
    root: {
        display: 'flex',
    },
    drawer: {
        [theme.breakpoints.up('sm')]: {
            width: drawerWidth,
            flexShrink: 0,
        },
    },
    appBar: {
        [theme.breakpoints.up('sm')]: {
            width: `calc(100% - ${drawerWidth}px)`,
            marginLeft: drawerWidth,
        },
    },
    // necessary for content to be below app bar
    toolbar: theme.mixins.toolbar,
    drawerPaper: {
        width: drawerWidth,
        position: "absolute",

    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(3),
        [theme.breakpoints.down("xs")]: {
            fontSize: '0.65rem'
        }
    },
}));

interface Props {
    open: boolean,
    setOpen(value: boolean): any,
    handleToggle(): void

}//

function SideBar({ open, setOpen, handleToggle }: Props): ReactElement {
    const classes = useStyles();

    console.log(classes);

    //const container = window !== undefined ? () => window().document.body : undefined;
    const drawer = (
        <div>
            <div className={classes.toolbar} />
            <Divider />
            <List>
                {routes.map((item: RouteItem, index) => (
                    <ListItem button key={index}>
                    <Link to={item.path || "/"} key={index}>
                        
                            {/* <ListItemIcon>{item.icon}</ListItemIcon> */}
                            <ListItemText primary={item.title} />
                       
                    </Link>
                     </ListItem>
                ))}
            </List>
            <Divider />
            <List>
                {['Settings', 'Logout'].map((text, index) => (
                    <ListItem button key={text}>
                        <ListItemIcon>{index % 2 === 0 ? <HomeWorkIcon /> : <ProductsIcon />}</ListItemIcon>
                        <ListItemText primary={text} />
                    </ListItem>
                ))}
            </List>
        </div>
    );
    const theme = useTheme();

    return (
        <nav className={classes.drawer}>
            <Drawer
                variant="temporary"
                anchor={theme.direction === 'rtl' ? 'right' : 'left'}
                open={open}
                onClose={handleToggle}
                classes={{
                    paper: classes.drawerPaper,
                }}
                ModalProps={{
                    keepMounted: true, // Better open performance on mobile.
                }}
            >
                {drawer}
            </Drawer>
        </nav>
    )
}

export default SideBar
