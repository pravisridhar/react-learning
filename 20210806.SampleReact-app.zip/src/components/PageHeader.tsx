import { Card, createStyles, makeStyles, Paper, Theme, Typography } from '@material-ui/core'
import React, { ReactElement } from 'react'


const useStyles=makeStyles((theme:Theme) =>createStyles({
    root: { 
        backgroundColor: "#fdfdff"
    }, 
    pageHeader: { 
        padding: theme.spacing(4) ,
        display:"flex",
        marginBottom: theme.spacing(1)
    }, 
    pageIcon: {
        display:"inline-block", 
        padding:theme.spacing(2), 
        color:"#3c4cb1"
    }, 
    pageTitle: {
        paddingLeft: theme.spacing(4),
    }
}));


interface IPageHeaderProps {
    pageTitle: string, 
    pageSubTitle: string, 
    displayIcon:any
}

function PageHeader({pageTitle, pageSubTitle,displayIcon}: IPageHeaderProps): ReactElement {
    const classes = useStyles(); 

    return (
        <Paper elevation={0} className={classes.root}>
            <div className={classes.pageHeader}>
                <Card className={classes.pageIcon}>
                    {displayIcon}
                </Card>
                <div className={classes.pageTitle}>
                    <Typography variant="h6" component="div">
                        {pageTitle}
                    </Typography>
                    <Typography variant="subtitle2" component="div">
                        {pageSubTitle}
                    </Typography>
                </div>
            </div>
        </Paper>
    )
}

export default PageHeader
