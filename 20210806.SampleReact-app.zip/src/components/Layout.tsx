import { CssBaseline } from '@material-ui/core'
import React, { ReactElement, ReactNode, useState } from 'react'
import Header from './Header'
import SideBar from "./SideBar"

interface ILayoutProps {
    children:ReactNode
}

export default function Layout({children}: ILayoutProps): ReactElement {
    const [open, setOpen] = useState(false);
    const handleDrawerToggle=() =>{
          setOpen(!open);
    }
    return (
        <div>
            <CssBaseline/>
            <Header open={open} setOpen={setOpen} handleToggle={handleDrawerToggle}/>
            <SideBar open={open} setOpen={setOpen} handleToggle={handleDrawerToggle} />
            <div style={{marginTop:"75px"}}></div>
            <main>
                {children}
            </main>
        </div>
    )
}
