import {RouteItem} from "./RouteItem";


import HomeIcon from "@material-ui/icons/Home";
import CreateIcon from "@material-ui/icons/CreateTwoTone";
import UpdateIcon from "@material-ui/icons/Update";
import DashboardIcon from "@material-ui/icons/Dashboard";
import PowerSettingsIcon from "@material-ui/icons/PowerSettingsNew";

import HomeFC from "../HomeFC";
import ProductList1 from "../products/basic/ProductList1";
import  ProductCreate from "../products/basic/ProductCreate";
import  ProductUpdate from "../products/basic/ProductUpdate";
import LoginComponent from "../controls/LoginComponent";
import ProductHome from "../products/basic/ProductHome";



export const routes:Array<RouteItem> = [
{
    key:"home-route", 
    title:"Home", 
    path:"/home",
    component:HomeFC,
    icon:HomeIcon,
    enabled:true, 
    requiresAuthentication:false
},
{
    key:"product-list", 
    title:"Product List", 
    path:"/products",
    component:ProductHome,
    icon:DashboardIcon,
    enabled:true, 
    requiresAuthentication:false
},
{
    key:"product-create", 
    title:"Add New Product", 
    path:"/products/create",
    component:ProductCreate,
    icon:CreateIcon,
    enabled:true, 
    requiresAuthentication:true
},
{
    key:"product-update", 
    title:"Update Product", 
    path:"/products/update",
    component:ProductUpdate,
    icon:UpdateIcon,
    enabled:true, 
    requiresAuthentication:true
},
{
    key:"login", 
    title:"Logout", 
    path:"/login",
    component:LoginComponent,
    icon:PowerSettingsIcon,
    enabled:true, 
    requiresAuthentication:false
}

]