import { createTheme, responsiveFontSizes, Theme } from "@material-ui/core";
import { blue, pink } from "@material-ui/core/colors";


const theme:Theme = createTheme({
    
    palette: {
        type:"light", 
        primary:{
            main: blue[600],
            light:blue[200],
            dark:blue[800] 
        }, 
        secondary:{
            main:pink[300], 
            light:pink[100], 
            dark:pink[800]
        }, 
        background: {
            default:"#f2f2f2"
        }
    },
    shape:{
        borderRadius: 10
    }, 
    overrides: { 
        MuiAppBar: {
            root: { 
                backgroundColor:"#fff",
                transform:"translateZ(0)"
            },
            colorPrimary:{
                backgroundColor:"#fff", 
                color:"primary"
            }
        }, 
        // MuiTypography: {
        //     h1: { 
        //         fontSize:'5rem',
        //         [theme.breakpoints.down("xs")]: { 
        //             fontSize:'3rem'
        //         }
        //     }
        // }
    }
})

export const lightTheme = responsiveFontSizes(theme);