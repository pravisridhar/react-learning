import {FC, ComponentType, ReactNode, ReactElement} from "react"; 


export interface RouteItem { 
    key:string,
    title:string, 
    path?:string, 
    component?:any, 
    icon?:ComponentType, 
    enabled:boolean, 
    tooltip?:string, 
    requiresAuthentication?:boolean 
}