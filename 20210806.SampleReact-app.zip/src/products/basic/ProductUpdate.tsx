import { Typography } from '@material-ui/core'
import React, { ReactElement } from 'react'

interface Props {
    
}

function ProductUpdate({}: Props): ReactElement {
    return (
        <div>
            <Typography variant="h2" component="div">
                Update product details .
            </Typography>
        </div>
    )
}

export default ProductUpdate
