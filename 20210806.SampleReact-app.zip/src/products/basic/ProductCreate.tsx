import { Typography } from '@material-ui/core'
import React, { ReactElement } from 'react'

interface Props {
    
}

function ProductCreate({}: Props): ReactElement {
    return (
        <div>
            <Typography variant="h2" component="div">
                Create a new Product.
            </Typography>
        </div>
    )
}

export default ProductCreate
