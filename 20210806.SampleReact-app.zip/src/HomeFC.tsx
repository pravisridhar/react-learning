import { Typography } from '@material-ui/core';
import React, { ReactElement } from 'react'
import { useState } from 'react'
import CustomButton from './controls/CustomButton';

interface IHomeFCProps {
    title?:string
}

function HomeFC(props: IHomeFCProps): ReactElement {

    //Hooks - available in Functional Components 
    const [counter, setCounter] = useState(0);
    
    const handleClick=(e:React.MouseEvent<HTMLButtonElement>) =>{
        setCounter(counter+1);
    }

    return (
        <div>
            <Typography variant="subtitle1">{props.title}</Typography>
            <p>
                counter is <span>{counter}</span>
                <CustomButton onClick={handleClick} text="Update Me" name="t1"/>
            </p>
        </div>
    )
}

export default HomeFC
