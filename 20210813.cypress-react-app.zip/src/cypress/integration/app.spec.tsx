//export { }

it("should show the site", () =>{
    cy.visit("/");
})
it("should work", () => { 
    cy.visit("/");
    cy.get("button").contains("Add Amount").click(); 
    cy.contains("2"); 
    cy.get("button").contains("-").click();
    cy.contains("1");
    cy.get("input").type("{backspace}5");
    cy.get("button").contains("Add Async").click();
    cy.get(".Counter_value__1kQ8F").should("have.text", "6");
})

