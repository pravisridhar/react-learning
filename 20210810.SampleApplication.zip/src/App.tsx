import React, { useState } from 'react';
import './App.css';
import { PageTitle, PageSubTitle, Header1 } from "./Headers"
import HomeComponent from "./HomeComponent";
import HomeFC from "./HomeFC"
import ProductHome from "../src/products/basic/ProductHome";
import { lightTheme } from "./config/AppTheme";
import { Button, StylesProvider, ThemeProvider } from '@material-ui/core';
import Layout from "./components/Layout"; 
import PageHeader from "./components/PageHeader"
import DashboardIcon from "@material-ui/icons/Dashboard";

import {createBrowserHistory as createHistory} from "history";
import {Router, Route, Switch } from "react-router-dom";
import {routes} from "./config/route.config";
import {RouteItem} from "./config/RouteItem";
import PrivateRoute from "./controls/PrivateRoute";

const history = createHistory(); 
//Functional Component -> stateless component 
//return a JSX fragment 
function App() {
  //onclick = () => data++; 
  
  const isAuthenticated:boolean = localStorage.getItem("auth")=="true"? true:false;
  
  return (
    
    <ThemeProvider theme={lightTheme}>
      <Router history={history}>
        <Layout>
        <Switch>
        {
          routes.map((item:RouteItem)=>(
            (item.requiresAuthentication) ? 
              <PrivateRoute exact key={item.key} path={item.path} 
                component={item.component} isAuthenticated={isAuthenticated}/>
              : 
              <Route exact key={item.key} path={item.path} component={item.component}/>
          ))
        }



      {/* <StylesProvider injectFirst> */}
        
          {/* <h2>Welcome to React!!</h2> */}
          {/* <PageTitle title="Start Page"/>
        <PageSubTitle title="" subtitle="subtitle" color="red"/> */}
          {/* <Header1/>
        <HomeComponent title="Home component"/>
        <HomeFC title="Home Functional Component"/> */}
          {/*  comment    */}
          
          {/* <PageHeader pageTitle="Application Home" 
              pageSubTitle="this is a sample application"
              displayIcon={<DashboardIcon fontSize="large"/>}/>

            <Button className="button">Sample</Button>

            <ProductHome /> */}
       
        </Switch> </Layout>
        {/* </StylesProvider> */}
        </Router>
    </ThemeProvider>
  );
}


export default App;
