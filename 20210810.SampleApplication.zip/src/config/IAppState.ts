import { ProductModel } from "../products/data/ProductModel";

export interface IAppState { 

    appName: string, 
    isAuthenticate: boolean, 
    user: { userName:string, fullName:string},
    products: { 
        productList: Array<ProductModel>, 
        selectedProduct: ProductModel, 
        selectedProductId: number, 
        isLoading:boolean, 
        errors: string 
    }
}