import { createStyles, Grid, InputAdornment, makeStyles, Paper, TableBody, TableCell, TableRow, TextField, Theme } from '@material-ui/core';
import React, { ReactElement, useEffect, useState } from 'react'
import { Link, useHistory } from 'react-router-dom';
import { useProduct } from '../../config/AppContext';
import CustomButton from '../../controls/CustomButton';
import { ITableHeaderCell, useTable } from '../../controls/useTable'
import { ProductLocalDataSource } from "../data/ProductLocalDataSource";
import ListIcon from "@material-ui/icons/LibraryBooksTwoTone";
import SearchIcon from "@material-ui/icons/Search";

import PageHeader from '../../components/PageHeader';
import {ProductService} from "../data/ProductService";
import { ProductModel } from '../data/ProductModel';
import LoopRoundedIcon  from '@material-ui/icons/LoopRounded';

interface Props {

}

const headerCells: Array<ITableHeaderCell> = [
    { id: "ProductName", label: "Product Name" },
    { id: "UnitPrice", label: "Unit Price" },
    { id: "unitsinstock", label: "Units In Stock" },
    { id: "operations", label: "Operations" },
];
const useStyles = makeStyles((theme: Theme) => createStyles({
    pageContent: {
        padding: theme.spacing(3),
        margin: theme.spacing(5)
    },
    searchInput: {
        opacity: '0.9',
        width: '75%',
        marginRight: theme.spacing(1),
        padding: `0px 5px `,//'0px 8px',
        fontSize: '0.8rem',
        '&:hover, &.active': {
            backgroundColor: '#d2d2d2',
            borderBottom: '2px dotted gray'
        },
        '& .MuiSvgIcon-root': {
            marginRight: theme.spacing(2),
        }
    }
}))
interface IFilterProps {
    fn(items: any): Array<{}>
}

function ProductListMain({ }: Props): ReactElement {
    
    const {state, dispatch} = useProduct();
    const classes = useStyles();
    
    const history = useHistory();
    const [filterFn, setFilterFn] = useState<IFilterProps | undefined>({ fn: items => items })
    //let records = []; //ProductLocalDataSource.getAllProducts();
    const [ records, setRecords] = useState<ProductModel[]>([]);
    const [isLoading, setIsLoading] = useState(true)
 
    //componentDidMount, shouldComponentUpdate, componentDidUpdate, getDerivedStateFromProps,
    //getSnapshotBeforeUpdate
    useEffect(()=>{
        async function fetchRecords() {
            let service = new ProductService();
            let responseData = await service.fetchAllProducts(); 
            console.log('Fetched rows', responseData); 
            setRecords(responseData);
            dispatch({type:"AllProducts", payload:{productList:responseData}});
            setIsLoading(false);
        }
        fetchRecords();
        // if(state.products.productList.length==0) { 
        //     records=ProductLocalDataSource.getAllProducts();
        //     console.log("State Object Before: " , state);
        //     dispatch({type:"AllProducts", payload:{productList:records}});
        // } else {
        //     console.log("State Object After: " , state);
        // }

    }, []);
    
    const {
        TblContainer,
        TblHeader,
        TblPagination,
        recordsAfterPagination
    } = useTable({ records: state.products.productList, headerCells: headerCells, filterfn: filterFn })

    const handleSelect = (e: React.MouseEvent<HTMLButtonElement>) => {
        let pId = parseInt(e.currentTarget.value);
        console.log(pId);
        let matchingItems = state.products.productList.find(c => c.productId === pId);
        if(matchingItems)
            dispatch({
                type:"ProductDetails" , 
                payload: {
                    selectedProduct: matchingItems,
                    selectedProductId: pId
            }});
        history.push("/products/update");
        console.log("being redirected")
        //if(selectedItem) selectedItem(pId);
    }
    const handleNewClick = (e: React.MouseEvent<HTMLButtonElement>) => {
       
        history.push("/products/create");
    }
    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        let target = e.target;
        setFilterFn({
            fn: (items: any) => {
                if (target.value == "")
                    return items;
                else
                    return items.filter((x: any) => x.productName.toLowerCase().includes(target.value));
            }
        })
    }
    if(isLoading)
        return <div style={{textAlign:'center'}}>
                <LoopRoundedIcon fontSize="large"/>
                <p>Please wait. The page is loading....</p>
        </div>
    else 
    return (
        <div>
            <PageHeader
                pageTitle="Products List" pageSubTitle="All products available in the store are listed here."
                displayIcon={<ListIcon fontSize="small" />} />
            <Paper elevation={1} className={classes.pageContent}>
                <Grid container>
                    <Grid item md={2} >
                        <CustomButton text="Add New Product"
                            color="secondary" name="addNew"
                            onClick={handleNewClick} />
                    </Grid>
                    <Grid item md={6}>
                        <TextField
                            fullWidth={true}
                            label="Search Products"
                            name="search"
                            className={classes.searchInput}
                            onChange={handleSearch}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchIcon />
                                    </InputAdornment>
                                )
                            }}
                        />
                    </Grid>
                    <Grid item md={4}>
                        <TblPagination records={state.products.productList} />
                    </Grid>
                </Grid>

                <TblContainer>
                    <TblHeader header={headerCells} />
                    <TableBody>
                        {
                             
                            //records.map(
                            recordsAfterPagination()?.map(
                                (item: any) => (
                                    <TableRow key={item.productId}>
                                        <TableCell>{item.productName}</TableCell>
                                        <TableCell>{item.unitPrice}</TableCell>
                                        <TableCell>{item.unitsInStock}</TableCell>
                                        <TableCell>
                                            <Link to="/products/update" >
                                                <CustomButton name="btn1"
                                                    text="Edit"
                                                    size="small"
                                                    value={item.productId}
                                                    onClick={handleSelect}
                                                />
                                            </Link>
                                        </TableCell>
                                    </TableRow>
                                )
                            )
                        }
                    </TableBody>
                </TblContainer>

            </Paper>
        </div>
    )
}

export default ProductListMain;