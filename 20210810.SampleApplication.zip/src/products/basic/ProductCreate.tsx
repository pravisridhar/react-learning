import { createStyles, makeStyles, Paper, TextField, Theme, Typography } from '@material-ui/core'
import { useFormik } from 'formik';
import React, { ReactElement, ReactNode } from 'react'
import PageHeader from '../../components/PageHeader';
import { useProduct } from '../../config/AppContext';
import {validationSchema } from '../data/ProductModel';
import UpdateIcon from "@material-ui/icons/Update";
import CustomButton from "../../controls/CustomButton";
import { useHistory } from 'react-router-dom';
import { ProductLocalDataSource } from '../data/ProductLocalDataSource';
import { ProductService } from '../data/ProductService';

interface Props {
    
}
const useStyles = makeStyles((theme: Theme) => createStyles({
    root: {
        "& .MuiFormControl-root": {
            width: '80%',
            margin: theme.spacing(1)
        },
        "& > * + *": {
            width: '80%',
            margin: theme.spacing(1)
        }
    },
    pageContent:{
        padding:theme.spacing(3),
        margin:theme.spacing(5)
    }

}))

function ProductCreate({}: Props): ReactElement {
    const classes = useStyles();
    const {state, dispatch} = useProduct();
    const history = useHistory();

    const formik = useFormik({
        initialValues: {productId:0, productName:'', unitPrice:0, unitsInStock:0},
        validationSchema: validationSchema,
        
        onSubmit:(values)=>{
            //alert('validated');
            let pId = state.products.productList.length + 1; 
            values.productId = pId; 
            let service = new ProductService(); 
            service.createProduct(values)
            //ProductLocalDataSource.create(values);
            dispatch({type:"CreateProduct", payload: { selectedProduct: values}});
            
            service.fetchAllProducts().then(data=>{
                dispatch({type:"AllProducts", payload: { productList: data}});
                history.push("/products");
            });
        }
    })
    return (
        <>
        <PageHeader 
            pageTitle="Add New Products" pageSubTitle="Use this page to add a new product."
            displayIcon={<UpdateIcon fontSize="small"/>}/>
        <Paper className={classes.pageContent}>
        <form className={classes.root} autoComplete="off" onSubmit={formik.handleSubmit} >
            <TextField
                fullWidth
                id="productName"
                name="productName"
                label="Product Name"
                variant="outlined"
                value={formik.values.productName}
                onChange={formik.handleChange}
                error={formik.touched.productName && Boolean(formik.errors.productName)}
                helperText={formik.touched.productName && formik.errors.productName}
                />
                <TextField
                fullWidth
                id="unitPrice"
                name="unitPrice"
                label="Unit Price"
                variant="outlined"
                value={formik.values.unitPrice}
                onChange={formik.handleChange}
                error={formik.touched.unitPrice && Boolean(formik.errors.unitPrice)}
                helperText={formik.touched.unitPrice && formik.errors.unitPrice}
                />
                <TextField
                fullWidth
                id="unitsInStock"
                name="unitsInStock"
                label="stock Level"
                variant="outlined"
                value={formik.values.unitsInStock}
                onChange={formik.handleChange}
                error={formik.touched.unitsInStock && Boolean(formik.errors.unitsInStock)}
                helperText={formik.touched.unitsInStock && formik.errors.unitsInStock}
                />
                <CustomButton text="Submit" type="submit" name="submit" color="secondary" size="large"/>
        </form>
        </Paper>
        </>
    )
}

export default ProductCreate
