import { TableBody,  TableCell, TableRow } from '@material-ui/core';
import React, { ReactElement } from 'react'
import CustomButton from '../../controls/CustomButton';
import { ITableHeaderCell, useTable } from '../../controls/useTable'
import {ProductLocalDataSource} from "../data/ProductLocalDataSource";

interface Props {
    selectedItem?(id:number):void
}

const headerCells:Array<ITableHeaderCell> = [
    { id:"ProductName", label: "Product Name"},
    { id:"UnitPrice", label: "Unit Price"},
    { id:"unitsinstock", label: "Units In Stock"},
    { id:"operations", label: "Operations"},
];

function ProductList1({selectedItem}: Props): ReactElement {
    const records = ProductLocalDataSource.getAllProducts();
    
    const { 
        TblContainer, 
        TblHeader,
        TblPagination,
        recordsAfterPagination
    } = useTable({records, headerCells})

    const handleSelect=(e:React.MouseEvent<HTMLButtonElement>) =>{
        let pId = parseInt(e.currentTarget.value);
        console.log(pId);
        if(selectedItem) selectedItem(pId);
    }
    return (
        <div>
            <TblContainer>
                <TblHeader header={headerCells}/>
                <TableBody>
                    {
                        //records.map(
                            recordsAfterPagination().map(
                             (item :any)=>(
                                <TableRow key={item.productId}>
                                    <TableCell>{item.productName}</TableCell>
                                    <TableCell>{item.unitPrice}</TableCell>
                                    <TableCell>{item.unitsInStock}</TableCell>
                                    <TableCell>
                                        <CustomButton name="btn1"
                                            text="Select"
                                            size="small"
                                            value={item.productId}
                                            onClick={handleSelect}/>
                                    </TableCell>
                                </TableRow>
                            )
                        )
                    }
                </TableBody>
            </TblContainer>
            <TblPagination records={records}/>  
        </div>
    )
}

export default ProductList1
