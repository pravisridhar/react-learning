//Folder: Products 
//  Sub Folder: basic
//      File: ProductHome.tsx

import React, { Component, ReactElement } from 'react'
import { productList, ProductLocalDataSource } from '../data/ProductLocalDataSource';
import { ProductModel } from '../data/ProductModel'
import Header  from "../../components/Header"
import ProductList from "./ProductList";
import { Typography } from '@material-ui/core';
import ProductList1 from "./ProductList1";

interface IProductHomeProps {
    
}
interface IProductHomeState {
    productList: Array<ProductModel>, 
    selectedProduct: ProductModel | null, 
    selectedProductId: number,
    open:boolean
}


const ProductDetails = ({item}:{item:ProductModel|null}):ReactElement => { 
    return (
        <div>
            <h3>Product details</h3>
            <p> Product Name: {item?.productName} </p>
            <p> Units In Stock: {item?.unitPrice} </p>
            <p> Stock Level: {item?.unitsInStock} </p>
            <p> Product Id: {item?.productId} </p>
        </div>
    )
}
class ProductHome extends Component<IProductHomeProps, IProductHomeState> {
    constructor(props:IProductHomeProps){
        super(props);
        this.state={
            productList:[],
            selectedProduct:null,
            selectedProductId:0,
            open:true
            
        }
    }
    
    //Creation: constructor, getDerivedStateFromProps, ComponentDidMount
    componentDidMount() { 
        this.refreshList();
    }
    
    refreshList() { 
        let items = ProductLocalDataSource.getAllProducts(); 
        this.setState({
            ...this.state, //{ pL:[], sP: {obje}, SPI:99 } 
            productList:items // pL:items
            //{ pL:items, sP: {}, SPI:0 } 
        });
    }
    selectProduct = (id:number) => { 
        var item = ProductLocalDataSource.getProduct(id); 
        if(item)
        {
            this.setState({ ...this.state, selectedProduct:item, selectedProductId:id});
            console.log(item);
        }
    }
    setOpen = (value:boolean) : any => { this.setState({...this.state, open:!this.state.open}); }
    handleToggle = () : any => { this.setState({...this.state, open:!this.state.open});}
    render() {
        const open=true;    
        
        return (
            <div>   
                {/* <Header open={true} setOpen={this.setOpen} handleToggle={this.handleToggle}/> */}
                {/* <PageTitle title="Product Home"/> */}
                <Typography variant="h1" component="div">Large Font</Typography>
                {/* <ProductList 
                    productList={this.state.productList}
                    selectedItem ={this.selectProduct}
                    /> */}
                <ProductList1 selectedItem={this.selectProduct}/>
                <ProductDetails item={this.state.selectedProduct}/>
            </div>
        )
    }
}

export default ProductHome



