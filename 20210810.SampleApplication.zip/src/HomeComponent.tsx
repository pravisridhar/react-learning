import React, { Component } from 'react'

interface IHomeComponentProps {
    title:string
}
interface IHomeComponentState {
    counter:number,
}

class HomeComponent extends Component<IHomeComponentProps, IHomeComponentState> {
    constructor(props:IHomeComponentProps) { 
        super(props);
        this.state = { 
            counter : 0
        }
        //this.handleClick = this.handleClick.bind(this);
        //this.props.title = "New title";
        //this.setState({counter:100});
    }
    // handleClick(e:React.MouseEvent<HTMLButtonElement>) { 
    //     this.setState({
    //         counter: this.state.counter + 1
    //     });
    // }
    handleClick = (e:React.MouseEvent<HTMLButtonElement>) => {
        this.setState({
            counter: this.state.counter + 1
        });
    }

    render() {
        return (
            <div>
                <h3>{this.props.title}</h3>
                <p>
                    counter is : <span>{this.state.counter}</span>
                    <button onClick={this.handleClick}>Click Me</button>
                </p>
            </div>
        )
    }
}

export default HomeComponent
