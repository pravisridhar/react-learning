
import React, { Component } from 'react'
import { Redirect, Route, RouteComponentProps, RouteProps } from 'react-router-dom'

interface IPrivateRouteProps extends RouteProps {
    isAuthenticated:boolean   
}

export default class PrivateRoute extends Route<IPrivateRouteProps> {
    constructor(props: IPrivateRouteProps) { super(props); }

    render() {
        return (
            <Route render={(props: RouteComponentProps)=>{
                if(!this.props.isAuthenticated)
                    return <Redirect to="/login"/>
                if(this.props.component)
                    return React.createElement(this.props.component);
                if(this.props.render)
                    return this.props.render(props);
            }}/>
        )
    }
}
