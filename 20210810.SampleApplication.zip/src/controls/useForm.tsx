import React, { ReactElement, useState } from 'react'
import {useFormik} from "formik"
import { validate } from 'jest-validate';

export interface IUseFormProps {
    initialValues:{},
    validationSchema:any,
    validateOnChange?:boolean,
    validate?(e?:any):boolean
}
export interface IUseFormReturnProps{
    // values:any,
    // setValues({}):void,
    // errors:any,
    // setErrors({}):void,
    // handleChange(e:React.ChangeEvent<HTMLInputElement|HTMLTextAreaElement>):void,
    // resetForm(e:React.FormEvent) : void
    formik:any,
    formValues:{},
    setFormValues({}):void
}
function useForm({initialValues, validationSchema, validateOnChange, validate}: IUseFormProps): IUseFormReturnProps {
    const [formValues,setFormValues] = useState(initialValues);

    const formik = useFormik({
        initialValues:initialValues,
        validationSchema:validationSchema,
        onSubmit: (values)=>{
            setFormValues({...values});
        }
    })
    // const [values, setValues] = useState(initialValues); 
    // const [errors, setErrors] = useState({}); 
    // const handleChange = (
    //     e:React.ChangeEvent<HTMLInputElement|HTMLTextAreaElement>
    // ) => { 
    //     const { name, value} = e.target; 
    //     setValues({...values, [name]:value});
    //     if(validateOnChange) { 
    //         if(validate) validate({[name]:value})
    //     }
    // }
    // const resetForm= ( 
    //     e:React.FormEvent
    // ) => { 
    //     setValues(initialValues);
    //     setErrors({});
    // }
    return { 
        formik, formValues, setFormValues
    }
}

export default useForm
