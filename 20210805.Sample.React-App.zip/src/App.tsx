import React from 'react';
import './App.css';
import { PageTitle, PageSubTitle, Header1 } from "./Headers"
import HomeComponent from "./HomeComponent";
import HomeFC from "./HomeFC"
import ProductHome from "../src/products/basic/ProductHome";
import { lightTheme } from "./config/AppTheme";
import { Button, StylesProvider, ThemeProvider } from '@material-ui/core';
import Layout from "./components/Layout"; 
import PageHeader from "./components/PageHeader"
import DashboardIcon from "@material-ui/icons/Dashboard";

//Functional Component -> stateless component 
//return a JSX fragment 
function App() {
  //onclick = () => data++; 
  return (
    <ThemeProvider theme={lightTheme}>
      {/* <StylesProvider injectFirst> */}
        <Layout>
          {/* <h2>Welcome to React!!</h2> */}
          {/* <PageTitle title="Start Page"/>
        <PageSubTitle title="" subtitle="subtitle" color="red"/> */}
          {/* <Header1/>
        <HomeComponent title="Home component"/>
        <HomeFC title="Home Functional Component"/> */}
          {/*  comment    */}
          
          <PageHeader pageTitle="Application Home" 
              pageSubTitle="this is a sample application"
              displayIcon={<DashboardIcon fontSize="large"/>}/>

            <Button className="button">Sample</Button>

            <ProductHome />
        </Layout>
        {/* </StylesProvider> */}
    </ThemeProvider>
  );
}


export default App;
