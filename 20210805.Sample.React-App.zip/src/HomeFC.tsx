import React, { ReactElement } from 'react'
import { useState } from 'react'

interface IHomeFCProps {
    title:string
}

function HomeFC(props: IHomeFCProps): ReactElement {

    //Hooks - available in Functional Components 
    const [counter, setCounter] = useState(0);
    
    const handleClick=(e:React.MouseEvent<HTMLButtonElement>) =>{
        setCounter(counter+1);
    }

    return (
        <div>
            <h3>{props.title}</h3>
            <p>
                counter is <span>{counter}</span>
                <button onClick={handleClick}> Update Me!</button>
            </p>
        </div>
    )
}

export default HomeFC
