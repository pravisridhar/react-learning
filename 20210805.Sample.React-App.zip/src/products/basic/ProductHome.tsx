//Folder: Products 
//  Sub Folder: basic
//      File: ProductHome.tsx

import React, { Component, ReactElement } from 'react'
import { productList, ProductLocalDataSource } from '../data/ProductLocalDataSource';
import { ProductModel } from '../data/ProductModel'
import {Header1, PageTitle } from "../../Headers"
import ProductList from "./ProductList";

interface IProductHomeProps {
    
}
interface IProductHomeState {
    productList: Array<ProductModel>, 
    selectedProduct: ProductModel | null, 
    selectedProductId: number
}


const ProductDetails = ({item}:{item:ProductModel|null}):ReactElement => { 
    return (
        <div>
            <h3>Product details</h3>
            <p> Product Name: {item?.productName} </p>
            <p> Units In Stock: {item?.unitPrice} </p>
            <p> Stock Level: {item?.unitsInStock} </p>
            <p> Product Id: {item?.productId} </p>
        </div>
    )
}
class ProductHome extends Component<IProductHomeProps, IProductHomeState> {
    constructor(props:IProductHomeProps){
        super(props);
        this.state={
            productList:[],
            selectedProduct:null,
            selectedProductId:0 
        }
    }
    //Creation: constructor, getDerivedStateFromProps, ComponentDidMount
    componentDidMount() { 
        this.refreshList();
    }
    refreshList() { 
        let items = ProductLocalDataSource.getAllProducts(); 
        this.setState({
            ...this.state, //{ pL:[], sP: {obje}, SPI:99 } 
            productList:items // pL:items
            //{ pL:items, sP: {}, SPI:0 } 
        });
    }
    selectProduct = (id:number) => { 
        var item = ProductLocalDataSource.getProduct(id); 
        if(item)
        {
            this.setState({ ...this.state, selectedProduct:item, selectedProductId:id});
            console.log(item);
        }
    }

    render() {
        return (
            <div>
                <Header1 title="Product Home" subtitle="Manage products" />
                <PageTitle title="Product Home"/>
                <ProductList 
                    productList={this.state.productList}
                    selectedItem ={this.selectProduct}
                    />
                <ProductDetails item={this.state.selectedProduct}/>
            </div>
        )
    }
}

export default ProductHome



