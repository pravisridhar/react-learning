import React, { Component } from 'react'
import { ProductModel } from '../data/ProductModel'
import CustomButton from "../../controls/CustomButton";

interface IProductListProps {
    productList:Array<ProductModel>,
    selectedItem?(id:number):void,
}
interface IProductListState {
    
}

export default class ProductList extends Component<IProductListProps, IProductListState> {
    state = {}

    handleClick=(e:React.MouseEvent<HTMLButtonElement>) => {
        let pId = parseInt(e.currentTarget.value);
        console.log(pId);
        if(this.props.selectedItem) this.props.selectedItem(pId);
    }

    render() {
        return (
            <table className="table table-striped table-hover">
                    <thead>
                        <tr><th>Product Name</th><th>Unit Price</th><th></th></tr>
                    </thead>
                    <tbody>
                        {
                            this.props.productList.map(
                                (value, index)=>(
                                    <tr key={value.productId}>
                                        <td>{value.productName}</td>
                                        <td>{value.unitPrice}</td>
                                        <td>
                                            {/* <button
                                                value={value.productId} 
                                                onClick={this.handleClick} > 
                                                Select 
                                            </button> */}
                                            <CustomButton 
                                                name="selectbtn1"
                                                text="Select"
                                                size="small"
                                                onClick={this.handleClick}
                                                value={value.productId}/>
                                        </td>
                                    </tr>
                                ))
                        }
                    </tbody>
                </table>
        )
    }
}
