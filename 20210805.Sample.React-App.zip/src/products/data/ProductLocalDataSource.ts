//Folder: Products 
//  Sub Folder: basic
//      Sub Folder: data 
//          File: ProductLocalDataSource.ts

import { ProductModel } from "./ProductModel"

export const productList:Array<ProductModel> = [
    new ProductModel(101, "Markers", 10, 500), 
    new ProductModel(102, "Folders", 125, 450), 
    new ProductModel(103, "Pens", 25, 99), 
    new ProductModel(104, "Parker Pens", 75, 350), 
    new ProductModel(105, "Duster", 19, 887), 
];
export class ProductLocalDataSource { 

    static getAllProducts() : Array<ProductModel> { 
        return productList;
    }
    static getProduct(productId:number) : ProductModel | null { 
        let matchingProducts = 
                productList.filter( c => c.productId === productId); 
        if(matchingProducts.length) {
            return matchingProducts[0];
        } 
        return null;
    }
}