//Folder: Products 
//  Sub Folder: basic
//      Sub Folder: data 
//          File: ProductModel.ts

export class ProductModel {
    constructor(
        public productId:number, 
        public productName:string, 
        public unitPrice:number, 
        public unitsInStock:number, 
    ) { 

    }
}