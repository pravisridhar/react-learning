import { add } from "./calc"

describe("test suite for calc ops", () => { 
    it("is a simple test", () =>{ 
        //Arrange
        const expected = 10; 
        //Act
        const actual = 10; 
        //Assert
        expect(actual).toBe(expected);
    })

    it("should return 10 for add(5,5)", () => { 
        //Arrange
        const a=5, b=5; 
        const expected = a+b; 
        //Act
        const actual = add(a,b)
        //Assert
        expect(actual).toBe(expected); 
    })
    it("tests with different values ", () => { 
        const a=5, b=5; 
        const expected = a+b; 
        const actual = add(a,b+5);
        expect(actual).not.toBe(expected); 
    })
    it("should return b*b for arr(15, 10)", () => { 
        const a=15, b=5; 
        const expected = b+b; 
        const actual = add(a,b);
        expect(actual).toBe(expected); 
    })
    it("should return a*a for arr(8, 15)", () => { 
        const a=8, b=15; 
        const expected = a+a; 
        const actual = add(a,b);
        expect(actual).toBe(expected); 
    })
})

//npm i jest ts-jest @types/jest 
//npx ts-jest config:init