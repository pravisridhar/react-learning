//var i = 10; 

console.log('Welcome to JS/TS/React programming'); 

// INSTALL the TYPESCRIPT library 
/* 
    npm install typescript --global   
    //C:\Users\<username>\Appdata\roaming\npm  --> Global location 
    //the packages are available machine wide - all projects on the machine 
    
    npm uninstall typescript --global 

    //local installation is in the current project folder
    //<currentProjectFolder>\node_modules folder contains the package files 


*/

for(var index=0;index<10; index++){
    console.log(index); 
}

console.log('Outside the loop', index); 

//ES6 
for(let i=0; i<10; i++){
    console.log(i)
}
//console.log('Outside the loop', i);

//String, Number, Boolean, Date, Object, Null, Undefined, Symbol, 
var contact = "James"; //All variables are of variant data type  
contact = 10; 
//console.log(contact+contact.concat());

function Fn1(id, name) {
    console.log(arguments[0]); 
    for (let index = 0; index < arguments.length; index++) {
        console.log(arguments[index]);        
    }
    return id+ name;
}
console.log(Fn1)
Fn1(); 
Fn1(10); 
Fn1(10, 10); 
Fn1(10,20,40);

document.getElementById("btn1").addEventListener("click", Fn1);
document.getElementById("btn1").removeEventListener("click", Fn1);

