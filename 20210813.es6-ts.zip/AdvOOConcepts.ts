//enum 
enum AccountType  { None, Savings, Current }; 
let acType = AccountType.Savings; 
console.log(`Account type: ${acType}`);

interface IAccount { 
    Name:string, 
    Address?:string, //optional field
    deposit?(amount:number) : void

}
let v1:IAccount= {Name:"Acc"};
console.log(v1.Address)
let v3:IAccount= {Name:"Acc", Address:"ss"};



abstract class Account implements IAccount { 
    constructor( 
        private _id : number, 
        public Name: string, 
        protected _type: AccountType, 
        protected _balance: number
    ) { 
    
    }
    deposit(amount: number) : void { 
        this._balance+=amount; 
    }
    abstract withdraw(amount: number): void; 
    get Id() : number { return this._id;}
    get Balance() : number { return this._balance;}
}
class Savings extends Account { 
    constructor(id:number, name:string, type:AccountType, amount:number){
        super(id, name, type, amount);
    }
    withdraw(amount:number ) : void { this._balance -=amount;}
}
class MySavings extends Savings { 
    withdraw(amount: number) : void {
        this._balance -= amount;
    }
} 
let ac1 = new Savings(101, "Sample", AccountType.Savings, 5000); 
//npm i @types/node 
module.exports =  { AccountType, Savings}