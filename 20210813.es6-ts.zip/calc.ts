export function add(a:number, b:number) : number { 
    if(a>10)
        return b + b; 
    else if(b >  10)
        return a + a;
    else 
        return a + b;
}
