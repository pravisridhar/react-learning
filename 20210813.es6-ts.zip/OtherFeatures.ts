var fin = require("./AdvOOConcepts");  //NodeJs implementation - CommonJs syntax 

//Native ES2015 
//import { something, something2 } from "./somewhere"; 
//export something; 
//export default something; //only one default export is allowed from a file.  
//import something from "./somewhere";

//source file 1.js;
//export Fn1
//export Fn2 
//export class MyComp { F1() { return Fn1; } F2() { }} 

//source file 2.js;
//import {MyComp, Fn1 } from "./exportFile.js"; 


var v2 = new fin.Savings(111,'',fin.AccountType.Current, 1000 )

class Customer { 
    //Fields 
   /*private*/ customerId: number; 
    customerName: string; 

    constructor(name: string, id: number) { 
        this.customerId = id; 
        this.customerName = name; 
    }
    //Methods 
    showDetails() : void { 
        console.log(`ID: ${this.customerId}, Name: ${this.customerName}`);
    }
}
let c1 = new Customer( "Samuel", 10);
c1.showDetails();
c1.customerId = 122; c1.customerName="Sample";
c1.showDetails();
//npx tsc --outDir dist otherfeatures.ts 
//node dist/otherfeatures.js 

class Employee { 
    constructor(
        private empId:number, 
        private empname: string
    ) { }

    //Properties for the class 
    get empID() : number { return this.empId; }
    set empID(value:number) { this.empId=value; }
    get empName() : string { return this.empname}
    set empName(value:string) { this.empname=value; }
}
let e1 = new Employee(10, "Joe"); 
console.log(`Id: ${e1.empID}, ${e1.empName}`); 
//npx tsc -t "ES5" --outDir dist otherfeatures.ts 
//node dist/otherfeatures.js 

class StaticClass {
    static id:number = 100; 
    static show() { 
        console.log(StaticClass.id);
    }
}
StaticClass.show(); 
const MyHelper = { 
    show : ()=> { 
        console.log('show'); 
    }
}
MyHelper.show(); 


interface ISample { empId:number}
interface ISample2 { custId:string} 

type Sample  = ISample | ISample2; /// Union the types 

let s1:Sample = { empId:10 }; 
let s2:Sample = { custId:"One" };

function a1 ( t:Sample) { 
    if("empId" in t)
        return t.empId;
    else  if ("custId" in t)
        return t.custId;
    // if(typeof t === "isample")
    //  console.log(t.empId);
    //  else if(typeof t === 'ISample2')
    //  console.log(t.custId);
}
a1({empId:100}); 
a1({custId:"String"});

class Test<T> { 
    list: Array<T>;
    add(item:T) { 
        this.list.push(item);
    }
    show() { 
        for (let index = 0; index < this.list.length; index++) {
            console.log(this.list[index]);
        }
    }
}
let obj1 = new Test<ISample>(); 
obj1.add({empId: 1});
obj1.add({empId: 2});
obj1.show();