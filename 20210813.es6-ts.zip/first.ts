let count = 1; //Block-scoped variables 
console.log("Welcome to TS programming");

//compiler in TypeScript => tsc
//npx -> NPM executor, download missing packages into the local repository and execute 
//npx  tsc  --outDir dist  filename.ts 
//node  dist\filename.js 

//1. templated strings 
//` -backquote char to define a templated (interpolation) string 
let company = "Unisys"; 
console.log(`Company is : ${30+40}`); 
console.log('Company is ' + company);
//URL: `${baseUrl}\${company}\{item}`
//URL: baseUrl + "\" + company + "\" + item

//2. Block scoped variables 
for(let i=0; i<10; i++){
    console.log(i)
    //i="";
}

//console.log('Outside the loop', i);

//TS defines the data types and is strong typing 
let city:string = "Bengaluru"; 
city = "Chennai";
let country; 
country = 10; 
country = "Same";
//"any" data type is as good as var in JS 

const Age = 10; 
//Age = 999; 
//Function arguments and return types are "any" by default 
function F1(id) { 
    return id;
}
F1(54);
function F2(id:number, name:string) : string { 
    return id.toString() + name; 
    //return 10; 
}
F2(10, "hello");
//F2();


let F3 = function(id:number) : number { 
    return id;
}
F3(10); 


function F4( fn: (id:number)=>number ) { 
    fn(10);
}
//arrow syntax (ES6 - JS/TS)
let F5 = (id:number):string => (id++).toString(); 

F4(F1);

//Destructuring : ReST AND SPREAD 
let fruits = ["apples", "mangoes", "oranges"]; 
// let a = fruits[0]; 
// a = a + " " ; 
//SPreAD => ... 
let [a,b,c] = [...fruits];
console.log(a, b, c);
let obj  = { x:10, y:20};  //new Object(), obj.x, obj.y 
let {x, y} = obj; 
console.log(x, y);

interface IData { id:number; name1: string}; 
interface IData2 { str: string, length1: number, startsWith:string};
let obj2:IData = { id:1000, name1:"100"}; 
function F6( args:IData): IData2 {
    return {str: args.name1, length1: args.name1.length, startsWith: args.name1[0]}
}
F6({id:100, name1:"string"}); 
function F7(arg:{id:string, name1:string}) : any { 
    return arg.id + arg.name1;
}

let obj5 = F6({id:100, name1:"string"}); ; 
console.log(obj5.str, obj5.length1)

let obj6 = { location1:"One"};

let str1 = F6({id:100, name1:"string"}).str; 
let loc1 = obj6.location1;
let len = F6({id:100, name1:"string"}).length1;

let {str, ...obj8} = {...F6({id:100, name1:"string"}), ...obj6};

console.log(str, Object.keys(obj8));








